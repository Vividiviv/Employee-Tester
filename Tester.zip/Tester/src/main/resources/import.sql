insert into Employee(eid,ename,salary,position) values(1,'Divyanshu Mishra',100000,'Java developer');
insert into Employee(eid,ename,salary,position) values(2,'Ankur Garg',150000.00,'Android developer');
insert into Employee(eid,ename,salary,position) values(3,'Neelesh Pandey',20000.999,'UI developer');
insert into Employee(eid,ename,salary,position) values(4,'Shashwat Singh',80000,'Research Analyst');
insert into Employee(eid,ename,salary,position) values(5,'Jai Verma',50000,'Tester');